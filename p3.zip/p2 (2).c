#include <stdio.h>

int Answer;

int main(void)
{
	int T, N, test_case;
	int i, j, temp, dir;// 0 left, 1 down, 2 right, 3 up ����
	//setbuf(stdout, NULL);
	int **room;
	int **visit;

	scanf_s("%d", &T);
	for (test_case = 0; test_case < T; test_case++)
	{
		Answer = 0;
		scanf_s("%d", &N);

		room = malloc(sizeof(int*)*N);
		visit = malloc(sizeof(int*)*N);

		for (i = 0; i < N; i++) {
			room[i] = malloc(sizeof(int)*N);
			visit[i] = malloc(sizeof(int)*N);
		}
		for (i = 0; i < N; i++) {
			scanf_s("%d", &temp);
			for (j = N - 1; j >= 0; j--, temp /= 10) {
				room[i][j] = temp % 10;
				visit[i][j] = 0;
			}
		}

		for (i = 0, j = 0, dir = 0; i < N && j < N && i >= 0 && j >= 0; ) {
			if (visit[i][j] == 0) {
				visit[i][j] = 1;
				if (room[i][j] != 0)
					Answer++;
			}

			if (room[i][j] == 0) {
				if (dir == 0) {
					j++;
				}
				else if (dir == 1) {
					i++;
				}
				else if (dir == 2) {
					j--;
				}
				else if (dir == 3) {
					i--;
				}
			}
			else if (room[i][j] == 1) {
				if (dir == 0) {
					i--; dir = 3;
				}
				else if (dir == 1) {
					j--; dir = 2;
				}
				else if (dir == 2) {
					i++; dir = 1;
				}
				else if (dir == 3) {
					j++; dir = 0;
				}
			}
			else if (room[i][j] == 2) {
				if (dir == 0) {
					i++; dir = 1;
				}
				else if (dir == 1) {
					j++; dir = 0;
				}
				else if (dir == 2) {
					i--; dir = 3;
				}
				else if (dir == 3) {
					j--; dir = 2;
				}
			}
		}
		printf("Case #%d\n", test_case + 1);
		printf("%d\n", Answer);
	}

	return 0;
}