#include <stdio.h>

int Answer;

float max(float a, float b) {
	if (a > b) return a;
	else return b;
}

float min(float a, float b) {
	if (a < b) return a;
	else return b;
}

int distance(int **lines, int N, int x, int y) {
	int dist1, dist2, result = 0;

	for (int i = 0; i < N; i++) {
		dist1 = max(lines[i][0] - x, lines[i][1] - y);
		dist2 = max(lines[i][2] - x, lines[i][3] - y);
		dist1 = min(dist1, dist2);
		if (result < dist1)
			result = dist1;
	}
	
	return result;
}

int battery_pos(int **lines, int N, int x, int y) {
	int max = distance(lines, N, x, y);

}

int main(void)
{
	int T, test_case, N, i, j, x, y;
	int **lines;

	scanf_s("%d", &T);
	for (test_case = 0; test_case < T; test_case++)
	{
		Answer = 0;
		scanf_s("%d", &N);
		lines = malloc(sizeof(int*)*N);
		for (i = 0; i < N; i++) {
			lines[i] = malloc(sizeof(int) * 4);
			for (j = 0; j < 4; j++) {
				scanf_s("%d", &lines[i][j]);
			}
		}

		for (i = 0; i < N; i++) {
			x += lines[i][0] + lines[i][2];
			y += lines[i][1] + lines[i][3];
		}
		x /= 2 * N;	y /= 2 * N;
		Answer = battery_pos(lines, N, x, y);

		printf("Case #%d\n", test_case + 1);
		printf("%d\n", Answer);

	}

	return 0;//Your program should return 0 on normal termination.
}