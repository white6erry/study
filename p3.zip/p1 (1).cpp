#include <string>
#include<iostream>
using namespace std;

char patterns[100];
int count = 0;

string rule1(string sentence) {
	string result;
	int i, head, count;
	char pattern;

	for (head = 0; head < sentence.size(); head++) {
		if (sentence[head] >= 'a' && sentence[head] <= 'z') {
			for (i = 0; i < ::count; i++) {
				if (sentence[head] == patterns[i])
					return "invalid";
			}
			pattern = sentence[head];
			patterns[::count++] = pattern;

			for (i = head + 1; sentence[i] != pattern && i < sentence.size(); i++) {
				result += sentence[i];
			}
			if (sentence[i] != pattern)
				return "invalid";
			result += ' ';
			head = i;
		}

		else if (sentence[head] == ' ')
			return "invalid";
		
		else if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z') {
			pattern = sentence[head + 1];
			count = 0;
			for (i = head + 2; pattern != sentence[i] && i < sentence.size(); i++) {
				count++;
			}

			if (count > 1) {
				result += sentence[head];
				result += ' ';
			}
			else {
				for (i = head; i < sentence.size(); i += 2)
					if (sentence[i + 1] != sentence[head + 1])
						break;

				if (sentence[i] >= 'a' && sentence[i] <= 'z') {
					result += sentence[head];
					result += ' ';
					continue;
				}
				else {
					if (result.size() >= 1)
						if (result[result.size() - 1] != ' ')
							result += ' ';
					for (i = head; i < sentence.size(); i += 2) {
						if (sentence[i + 1] == pattern) {
							result += sentence[i];
							result += sentence[i + 1];
						}
						else break;
					}
					result += sentence[i];
					result += " ";
					head = i;
				}
				
			}
		}
		else 
			result += sentence[head];
	}
	return result;
}

string rule2(string sentence) {
	string result;
	int i, head;
	char pattern;

	for (head = 0; head < sentence.size(); head++) {
		if (sentence[head] >= 'a' && sentence[head] <= 'z')
			return "invalid";

		if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z') {
			for (i = 0; i < ::count; i++) {
				if (sentence[head + 1] == patterns[i])
					return "invalid";
			}
			pattern = sentence[head + 1];
			patterns[::count++] = pattern;

			for (i = head; sentence[i + 1] == pattern; i += 2) {
				result += sentence[i];
			}
			result += sentence[i];
			head = i;
		}
		else
			result += sentence[head];
	}
	return result;
}

string solution(string sentence) {
	string answer = "";
	::count = 0;

	answer = rule1(sentence);

	if (answer == "invalid")
		return "invalid";
	answer = rule2(answer);
	if (answer.back() == ' ')
		answer.pop_back();

	if (answer[0] == ' ')
		answer.erase(0, 1);

	return answer;
}

/*
string solution(string sentence) {
	string answer = "";
	char pattern;
	int i, j, head = 0;
	::count = 0;

	while (head < sentence.size()) {
		pattern = NULL;

		if (sentence[head] >= 'a' && sentence[head] <= 'z') {
			// ���� �ߺ� Ȯ��
			for (i = 0; i < ::count; i++)
				if (sentence[head] == patterns[i])
					return "invalid";

			// ���� ���� ����
			pattern = sentence[head];
			patterns[::count++] = pattern;

			if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z')
				return "invalid";

			if (sentence[head + 2] >= 'a' && sentence[head + 2] <= 'z') {
				for (j = 0; j < ::count; j++)
					if (sentence[head + 2] == patterns[j])
						return "invalid";

				// ���� ���� ����
				pattern = sentence[head + 2];
				patterns[::count++] = pattern;

				for (j = head + 1; j < sentence.size(); j += 2) {
					if (sentence[j + 1] != pattern)
						break;
					else
						answer += sentence[j];
				}
				head = j + 2;
				answer += sentence[j];
			}
			else {
				for (i = head + 1; i < sentence.size(); i++) {
					if (sentence[i] == pattern)
						break;
					else
						answer += sentence[i];
				}
				head = i + 1;
			}
			
			answer += " ";
			
		}
		// ��Ģ 2�� ����
		else if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z') {

			for (i = 0; i < ::count; i++)
				if (sentence[head + 1] == patterns[i])
					return "invalid";

			// ���� ���� ����
			pattern = sentence[head + 1];
			patterns[::count++] = pattern;

			for (i = head; i < sentence.size(); i += 2) {
				if (sentence[i + 1] != pattern)
					break;
				else
					answer += sentence[i];
			}
			head = i + 1;
			answer += sentence[i];
			answer += " ";
		}
		else {
			answer += sentence[head++];
		}
	}

	if (answer[answer.size() - 1] == ' ')
		answer.pop_back();

	return answer;
}
*/

void main() {
	/*
	cout << solution("BeBeBcDkDkDc") << endl;		//BBB DDD
	cout << solution("GdGdGdGHaHaHcRcKbK") << endl;	// GGGG HHH R KK
	cout << solution("HELLOWORLD") << endl;			
	cout << solution("HaEaLaLaObWORLDb") << endl;	//HELLO WORLD
	cout << endl;
	
	cout << solution("aHELLOa bWORLDb") << endl;
	cout << solution("HaEaLaLObWORLDb") << endl;
	cout << solution("HaEaLaLaOWaOaRaLaD") << endl;
	cout << solution("abHELLObcWORLD") << endl;
	cout << solution("abHELLObaWORLD") << endl;
	cout << endl;
	
	cout << solution("aHbEbLbLbOacWdOdRdLdDc") << endl;	//HELLO WORLD
	cout << solution("SpIpGpOpNpGJqOqA") << endl;
	cout << solution("AxAxAxAoBoBoB") << endl;
	
	cout << solution("aSIGONGaJqOqA") << endl;
	cout << solution("SIGONGqJOAq") << endl;
	cout << solution("aBBBaIIIIkAAk") << endl;
	
	cout << solution("ANDvIvLIKEeAfIfRfPfLfAfNfEe") << endl;*/
	//cout << solution("ANDgIgLhIhKhEMOUNTAINjSOjIkWILLkBElTHEREl") << endl;
	cout << solution("SIGONGqJOAqbYOb") << endl;
	cout << solution("SIGONGJqOqAYbO") << endl;
	cout << solution("SIGONGaJqOqAaYO") << endl;
	
	// AAAgBgaCCCa
	// AAAgBgCaCaC
	// AAAgBgCCC
	//cout << solution("") << endl;

}