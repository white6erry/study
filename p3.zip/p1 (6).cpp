#include <vector>
#include <iostream>

using namespace std;

int MOD = 20170805;
int count;

void route(int m, int n, vector<vector<int>> city_map) {
	int i;
	if (m == city_map.size() - 1 && n == city_map[0].size() - 1) {
		::count++;
		return;
	}
	if (city_map[m][n] == 0) {

		if (m < city_map.size() - 1) {
			if (city_map[m + 1][n] == 2 && m < city_map.size() - 2) {
				for (i = m + 1; i < city_map.size(); i++)
					if (city_map[i][n] != 2)
						break;
				route(i, n, city_map);
			}
			else if(city_map[m + 1][n] == 0)
				route(m + 1, n, city_map);
		}
			
		if (n < city_map[0].size() - 1) {
			if (city_map[m][n + 1] == 2 && n < city_map[0].size() - 2) {
				for (i = n + 1; i < city_map[0].size(); i++)
					if (city_map[m][i] != 2)
						break;
				route(m, i, city_map);
			}
			else if (city_map[m][n + 1] == 0)
				route(m, n + 1, city_map);
		}
	}
}

int solution(int m, int n, vector<vector<int>> city_map) {
	int answer = 0;
	::count = 0;

	route(0, 0, city_map);
	answer = ::count % MOD;

	return answer;
}

int main() {
	int n = 50;
	vector<vector<int>> map1, map2, map3(n, vector<int>(n, 0));

	map1 = { { 0, 0, 0 },{ 0, 0, 0 },{ 0, 0, 0 } };
	map2 = { { 0, 2, 0, 0, 0, 2 },{ 0, 0, 2, 0, 1, 0 },{ 1, 0, 0, 2, 2, 0 } };
	

	cout << solution(3, 3, map1) << endl;
	cout << solution(3, 6, map2) << endl;
	cout << solution(n, n, map3) << endl;

	return 0;
}