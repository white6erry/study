#include <string>
#include<iostream>
using namespace std;

string solution(string sentence) {
	int i, j, head = 0,
		tail = sentence.length() - 1,
		count = 0;
	bool rule1 = false, 
		rule2 = false;
	char pattern;
	char patterns[1000];
	string word, 
		answer = "";

	while (head <= tail) {
		word = "";
		rule1 = false;
		rule2 = false;

		if (sentence[head] == ' ' || (head == tail && sentence[head] >= 'a' && sentence[head] <= 'z'))
			return "invalid";

		//��Ģ 2 Ȯ��
		if (sentence[head] >= 'a' && sentence[head] <= 'z') {
			pattern = sentence[head];

			// ��Ģ2 �ι��̻� ���
			if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z')
				return "invalid";

			for (i = 0; i <= count; i++)
				if (pattern == patterns[i])
					return "invalid";

			// ������ ������ ���� ����
			patterns[count++] = pattern;
			head += 1;

			// tail ã��
			for (i = head; i < sentence.length(); i++) {
				if (sentence[i] == pattern) {
					tail = i - 1;
					rule2 = true;
					break;
				}
			}
		}

		// ��Ģ 1 Ȯ��
		if (sentence[head + 1] >= 'a' && sentence[head + 1] <= 'z') {
			pattern = sentence[head + 1];

			for (i = 0; i <= count; i++)
				if (pattern == patterns[i])
					return "invalid";
			patterns[count++] = pattern;

			for (i = head; i < sentence.length(); i += 2) {
				if (pattern == sentence[i + 1])
					word += sentence[i];
				else
					break;
			}
			tail = i;
			word += sentence[tail];
		}
		else {
			for (i = head; i <= tail; i++) {
				if (sentence[i] >= 'a' && sentence[i] <= 'z') {
					tail = i;
					rule1 = true;
					break;
				}
				word += sentence[i];
			}
		}

		// �ܾ� �߰�
		if (word != "") {
			if (answer == "")
				answer.append(word);
			else
				answer.append(' ' + word);
		}

		if (rule2)
			head = tail + 2;
		else if (rule1)
			head = tail;
		else
			head = tail + 1;
		tail = sentence.length() - 1;
		
	}

	if (answer == "")
		return "invalid";
	else
		return answer;
}

void main() {
	cout << solution("aHELLOa") << endl;	//rule2
	cout << solution("HaEaLaLaO") << endl;	//rule1
	cout << solution("aHaEaLaLaOa") << endl;//invalid
	cout << endl;
	cout << solution("HELLOWORLD") << endl;
	cout << solution("HaEaLaLaObWORLDb") << endl;
	cout << solution("aHELLOa bWORLDb") << endl;
	cout << solution("HaEaLaLObWORLDb") << endl;
	cout << solution("aHELLOWORLDa") << endl;
	cout << endl;
	cout << solution("HaEaLaLaOWaOaRaLaD") << endl;
	cout << solution("abHELLObaWORLD") << endl;
	cout << endl;
	cout << endl;
	cout << solution("JbObA") << endl;
	cout << solution("aHbEbLbLbOacWdOdRdLdDc") << endl;
	cout << solution("HaEaLaLaObWORLDb") << endl;
	cout << solution("SpIpGpOpNpGJqOqA") << endl;
	cout << solution("AxAxAxAoBoBoB") << endl;
	cout << endl;
	cout << solution("aFbRbIbEbNbDbSbRbAbCbIbNbGacRESERVATIONcING") << endl;
	cout << solution("aNOWaRESERVEbEMOTICONbHUNDREDcGIVEc") << endl;
	cout << solution("HaEaLaLObWORLDb") << endl;
	cout << solution("aRIONaCARTbALLbCcHcAcNcCcE") << endl;
}