#include <iostream>
#include <math.h>
#include <vector>
using namespace std;

struct check_point {
	int x, y;
	check_point(int ix, int iy) {
		x = ix;
		y = iy;
	}
};

vector<check_point> points;
vector<int> visit;
int Answer;

int boost_dist(int a, int b) {
	if (abs(points[a].x - points[b].x) > abs(points[a].y - points[b].y))
		return abs(points[a].y - points[b].y);
	else
		return abs(points[a].x - points[b].x);
}

void dfs(int a, int b, int x) {
	if (Answer == 1)
		return;
	if (a == b) {
		Answer = 1;
		return;
	}
	else {
		visit[a] = 1;
		for (int i = 0; i < points.size(); i++) {
			if (i == a)
				continue;
			if (boost_dist(a, i) <= x && visit[i] == 0)
				dfs(i, b, x);
		}
	}
}

int main() {
	int N, Q, x, y, a, b;
	int i, j;

	cin >> N >> Q;
	/*
	N = 5; Q = 1;
	points.push_back(check_point(1, 2));
	points.push_back(check_point(3, 2));
	points.push_back(check_point(4, 4));
	points.push_back(check_point(6, 2));
	points.push_back(check_point(3, 9));
	*/
	for (i = 0; i < N; i++) {
		cin >> x >> y;
		points.push_back(check_point(x, y));
		visit.push_back(0);
	}

	for (i = 0; i < Q; i++) {
		Answer = 0;
		cin >> a >> b >> x;
		dfs(a - 1, b - 1, x);
		//dfs(2, 3, 2);
		
		if (Answer == 1)
			cout << "YES" << endl;
		else
			cout << "NO" << endl;

		for (j = 0; j < visit.size(); j++)
			visit[j] = 0;
	}

	return 0;
}