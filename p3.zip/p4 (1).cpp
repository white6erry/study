#include <iostream>
#include <algorithm>
using namespace std;

int n, k;
int power[200000];

void proc(int caseidx) {
	cin >> n >> k;
	for (int i = 0; i < n; ++i) {
		cin >> power[i];
	}
	sort(power, power + n);

	int ans = 0, j = 0;
	for (int i = 0; i < n; ++i) {
		while (j < n && power[j] - power[i] <= k) ++j;
		ans = max(ans, j - i);
	}
	cout << "Case #" << caseidx << '\n';
	cout << ans << '\n';
}

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(nullptr);
	int t;
	cin >> t;
	for (int i = 1; i <= t; ++i) {
		proc(i);
	}
	return 0;
}