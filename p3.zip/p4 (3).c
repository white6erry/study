#include <stdio.h>

int Answer;

void dfs(int **matrix, int N, int r, int c, int w) {
	if (r == 3 && c == 3) {
		if (Answer > w)
			Answer = w;
		return;
	}
	if (r < 3)
		dfs(matrix, N, r + 1, c, w + matrix[r][c]);
	if (c < 3)
		dfs(matrix, N, r, c + 1, w + matrix[r][c]);
}

int main() {
	int T, test_case, N, i, j;
	int **matrix;
	char *temp;
	char *a[] = { "011001", "010100", "010011", "101001", "010101", "111010" };
	T = 1;
	//scanf_s("%d", &T);
	for (test_case = 0; test_case < T; test_case++) {
		Answer = 10000000;
		//scanf_s("%d", &N);
		N = 6;
		matrix = malloc(sizeof(int*)*N);
		for (i = 0; i < N; i++) {
			matrix[i] = malloc(sizeof(int) * N);
			//scanf_s("%c", &temp);
			for (j = 0; j < N; j++) {
				matrix[i][j] = a[i][j] - '0';
				//matrix[i][j] = temp % 10;
				//temp /= 10;
			}
		}
		
		dfs(matrix, N, 0, 0, matrix[0][0]);
		printf("#%d %d\n", test_case + 1, Answer);
	}

	return 0;
}