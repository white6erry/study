#include <stdio.h>

int test_case, T, N, M;
int parent[100000][2];

int find(int x) {
	int result;
	if (parent[x][0] != x)
		result = find(parent[x][0]);
	return result;
}

int unite(int x, int y, int w) {
	int x_root, y_root;
	x_root = find(x);
	y_root = find(y);
	parent[y_root][0] = x_root;
	for (int i = 0; i < N; i++)
		if (parent[i][0] == parent[y_root][0])
			parent[i][1] = parent[x_root][1] - w;
}

int main(void) {
	int i, j;
	int a, b, w;
	char act;

	scanf_s("%d", &T);
	for (test_case = 0; test_case < T; test_case++) {
		scanf_s("%d %d", &N, &M);

		for (i = 0; i < N; i++) {
			parent[i][0] = i;
			parent[i][1] = 0;
		}

		for (i = 0; i < N; i++) {
			act = getchar();
			if (act == '!') {
				scanf_s("%d %d %d", &a, &b, &w);
				unite(a, b, w);
			}
			else {
				scanf_s("%d %d", &a, &b);
				if (find(a) == find(b))
					printf(" %d", parent[a] - parent[b]);
				else
					printf(" UNKNOWN");
			}
		}

		printf("#%d\n", test_case);
		printf("%d\n", Answer);
	}
	return 0;
}