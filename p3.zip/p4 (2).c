#include <stdio.h>

int Answer;

void quickSort(int *arr, int left, int right) {
	int pivot, left_temp, right_temp;
	left_temp = left;
	right_temp = right;
	pivot = arr[left];
	while (left < right) {
		while (arr[right] >= pivot && (left < right)) {
			right--;
		}
		if (left != right) {
			arr[left] = arr[right];
		}
		while (arr[left] <= pivot && (left < right)) {
			left++;
		}
		if (left != right) {
			arr[right] = arr[left];
			right--;
		}
	}
	arr[left] = pivot;
	pivot = left;
	left = left_temp;
	right = right_temp;
	if (left < pivot) quickSort(arr, left, pivot - 1);
	if (right > pivot) quickSort(arr, pivot + 1, right);
}

int main(void)
{
	int T, test_case, N, K, i, j;
	int *ability;
	//setbuf(stdout, NULL);

	scanf_s("%d", &T);
	for (test_case = 0; test_case < T; test_case++)
	{
		Answer = 0;
		scanf_s("%d %d", &N, &K);
		ability = malloc(sizeof(int)*N);

		for (i = 0; i < N; i++) 
			scanf_s("%d", &ability[i]);
		quickSort(ability, 0, N - 1);

		for (i = 0; i < N; i++) {
			for (j = i + 1; ability[j] <= ability[i] + K && j < N; j++)
				;
			if (Answer < j - i)
				Answer = j - i;
		}
		
		printf("Case #%d\n", test_case + 1);
		printf("%d\n", Answer);
	}

	return 0;
}