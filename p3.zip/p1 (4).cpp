#include <vector>
#include <iostream>

using namespace std;

int size;


void search(vector<vector<int>> picture, int m, int n, vector<vector<bool>> &visit) {
	::size++;
	visit[m][n] = 1;

	if (m != picture.size() - 1) {
		if (picture[m][n] == picture[m + 1][n] && !visit[m + 1][n])
			search(picture, m + 1, n, visit);
	}
	if (m != 0) {
		if (picture[m][n] == picture[m - 1][n] && !visit[m - 1][n])
			search(picture, m - 1, n, visit);
	}
	if (n != picture[0].size() - 1) {
		if (picture[m][n] == picture[m][n + 1] && !visit[m][n + 1])
			search(picture, m, n + 1, visit);
	}
	if (n != 0) {
		if (picture[m][n] == picture[m][n - 1] && !visit[m][n - 1])
			search(picture, m, n - 1, visit);
	}
}

vector<int> solution(int m, int n, vector<vector<int>> picture) {
	int number_of_area = 0;
	int max_size_of_one_area = 0;
	vector<int> answer(2);
	vector<vector<bool>> visit(m, vector<bool>(n, false));

	for (int i = 0; i < m; i++) {
		for (int j = 0; j < n; j++) {
			::size = 0;
			if (picture[i][j] != 0 && !visit[i][j]) {
				search(picture, i, j, visit);
				number_of_area++;
			}
			if (::size > max_size_of_one_area)
				max_size_of_one_area = ::size;
		}
	}

	answer[0] = number_of_area;
	answer[1] = max_size_of_one_area;
	return answer;
}

int main() {
	vector<int> answer(2);
	vector<vector<int>> problem = { { 1, 1, 1, 0 }, { 1, 2, 2, 0 }, { 1, 0, 0, 1 }, { 0, 0, 0, 1 }, { 0, 0, 0, 3 }, { 0, 0, 0, 3 } };

	answer = solution(6, 4, problem);

	cout << answer[0] << ' ' << answer[1] << endl;
}