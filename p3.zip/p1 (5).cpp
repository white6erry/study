#include <iostream>

using namespace std;

int count = 0;

void cal(int n, int p, int m, int max) {
	if (p == 0) {
		for (int i = 0; i < m; i++) {
			if (n / 3 == float(n) / 3)
				n /= 3;
			else break;
		}
		if (n == 1) {
			::count++;
		}
	}
	else {
		cal(n - 1, p - 1, m, max);
		if (n / 3 == float(n) / 3 && p <= 2*m - 2) {
			cal(n / 3, p, m - 1, max);
		}
	}
}

int solution(int n) {
	int answer = 0,
		max = 0,
		temp = n;
	::count = 0;

	while (temp > 0) {
		temp /= 3;
		temp--;
		temp--;
		max++;
	}
	cout << max<< ' ';
	cal(n, 2 * max, max, max);
	answer = ::count;
	return answer;
}

int main() {
	cout << solution(28697813) << endl;
	/*
	cout << solution(15) << endl;	//2
	cout << solution(24) << endl;
	cout << solution(41) << endl;
	cout << solution(2147483647) << endl;
	*/
}