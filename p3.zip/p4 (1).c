#include <stdio.h>
#define MAX_MAZE 16

int Answer;
int **maze;
int **visit;
int i, j;
int test_case;

void find_goal(int r, int c) {
	visit[r][c] = 1;
	if (maze[r][c] == 3 || Answer != 0) {
		Answer = 1;
		return;
	}
	else {
		if (c != MAX_MAZE - 1)
			if (visit[r][c + 1] == 0 && maze[r][c + 1] != 1)
				find_goal(r, c + 1);
		if(c != 0)
			if (visit[r][c - 1] == 0 && maze[r][c - 1] != 1)
				find_goal(r, c - 1);
		if (r != MAX_MAZE - 1)
			if (visit[r + 1][c] == 0 && maze[r + 1][c] != 1)
				find_goal(r + 1, c);
		if(r != 0)
			if (visit[r - 1][c] == 0 && maze[r - 1][c] != 1)
				find_goal(r - 1, c);
	}
}

int main() {
	int start_row, start_col;

	maze = malloc(sizeof(int*) * MAX_MAZE);
	visit = malloc(sizeof(int*) * MAX_MAZE);
	for (i = 0; i < MAX_MAZE; i++) {
		maze[i] = malloc(sizeof(int) * MAX_MAZE);
		visit[i] = malloc(sizeof(int) * MAX_MAZE);
	}

	for (test_case = 0; test_case < 10;) {
		Answer = 0;
		scanf_s("%d", &test_case);
		start_row = -1, start_col = -1;

		for (i = 0; i < MAX_MAZE; i++) {
			for (j = 0; j < MAX_MAZE; j++)
				visit[i][j] = 0;
		}

		for (i = 0; i < MAX_MAZE; i++) {
			scanf_s("%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d%1d", &maze[i][0], &maze[i][1], &maze[i][2], 
				&maze[i][3], &maze[i][4], &maze[i][5], &maze[i][6], &maze[i][7], &maze[i][8], &maze[i][9], 
				&maze[i][10], &maze[i][11], &maze[i][12], &maze[i][13], &maze[i][14], &maze[i][15]);
		}

		for (i = 0; i < MAX_MAZE && start_row == -1; i++) {
			for (j = 0; j < MAX_MAZE && start_row == -1; j++) {
				if (maze[i][j] == 2) {
					start_row = i;
					start_col = j;
					break;
				}
			}
		}

		find_goal(start_row, start_col);

		printf("#%d\n", test_case);
		printf("%d\n", Answer);
	}

	return 0;
}