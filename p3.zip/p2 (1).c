#include <stdio.h>
int Answer;

int main(void)
{
	int T, test_case, N, i, j, p, temp, K;
	int* stone;
	setbuf(stdout, NULL);
	scanf("%d", &T);

	for (test_case = 0; test_case < T; test_case++)
	{
		Answer = 0;
		scanf("%d", &N);
		stone = malloc(sizeof(int)*(N + 1));
		stone[0] = 0;
		for (i = 1; i <= N; i++) {
			scanf("%d", &temp);
			stone[i] = temp;
		}
		scanf("%d", &K);

		for (i = 0; i < N; i = temp) {
			temp = 0;
			for (j = i + 1; stone[j] <= stone[i] + K && j <= N; j++) {
				if (temp < stone[j])
					temp = j;
			}
			if (temp == 0) {
				Answer = -1;
				break;
			}
			Answer++;
		}

		printf("Case #%d\n", test_case + 1);
		printf("%d\n", Answer);
	}

	return 0;
}